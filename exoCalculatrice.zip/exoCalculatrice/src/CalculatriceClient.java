import java.io.*;
import java.net.Socket;

public class CalculatriceClient {

        public static void main(String[] args) {
            String SERVER_HOST = "localhost";
            int SERVER_PORT = 5000;

            try {
                Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
                System.out.println("Connecté au serveur sur le port " + SERVER_PORT);

                // Envoi de message au serveur
                OutputStream outStream = socket.getOutputStream();
                PrintWriter output = new PrintWriter(outStream, true);

                // Lecture de réponse du serveur
                InputStream inStream = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(inStream);
                BufferedReader input = new BufferedReader(isr);

                // Exemple d'envoi d'opération
                String message = "10 / 5";
                System.out.println("Envoi : " + message);
                output.println(message);

                String response = input.readLine();
                System.out.println("Réponse du serveur : " + response);

                socket.close();
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }
    }
