import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;


public class CapitalizeServer {


        public static void main(String[] args) {
            int SERVER_PORT = 5000;

            try {
                ServerSocket server = new ServerSocket(SERVER_PORT);
                System.out.println("Le serveur a démarré sur le port " + SERVER_PORT);

                while (true) {
                    Socket socket = server.accept();
                    System.out.println("Un client s'est connecté");

                    // Lecture du message du client
                    InputStream inStream = socket.getInputStream();
                    InputStreamReader isr = new InputStreamReader(inStream);
                    BufferedReader input = new BufferedReader(isr);

                    // Préparation pour envoyer la réponse
                    OutputStream outStream = socket.getOutputStream();
                    PrintWriter output = new PrintWriter(outStream, true);

                    String message = input.readLine();
                    System.out.println("Message reçu : " + message);

                    // Transformation en majuscules
                    String capitalizedMessage = message.toUpperCase();

                    // Envoi de la réponse
                    output.println(capitalizedMessage);

                    socket.close();
                }
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }
    }
