import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class CalculatriceServer {
    public static void main(String[] args) {
        int SERVER_PORT = 5000;

        try {
            ServerSocket server = new ServerSocket(SERVER_PORT);
            System.out.println("Le serveur a démarré sur le port " + SERVER_PORT);

            while (true) {
                Socket socket = server.accept();
                System.out.println("Un client s'est connecté");

                // Lecture de la requête du client
                InputStream inStream = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(inStream);
                BufferedReader input = new BufferedReader(isr);

                // Envoi de réponse au client
                OutputStream outStream = socket.getOutputStream();
                PrintWriter output = new PrintWriter(outStream, true);

                String message = input.readLine();
                System.out.println("Message reçu : " + message);

                String response = calculate(message);
                output.println(response);

                socket.close();
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private static String calculate(String input) {
        try {
            String[] parts = input.split(" ");
            if (parts.length != 3) {
                return "Format incorrect. Utilisez : OPERANDE1 OPERATION OPERANDE2 (ex : 5 + 3)";
            }

            double operand1 = Double.parseDouble(parts[0]);
            String operator = parts[1];
            double operand2 = Double.parseDouble(parts[2]);
            double result;

            switch (operator) {
                case "+":
                    result = operand1 + operand2;
                    break;
                case "-":
                    result = operand1 - operand2;
                    break;
                case "*":
                    result = operand1 * operand2;
                    break;
                case "/":
                    if (operand2 == 0) {
                        return "Erreur : division par zéro";
                    }
                    result = operand1 / operand2;
                    break;
                default:
                    return "Opérateur inconnu. Utilisez : +, -, *, /";
            }

            return "Résultat : " + result;
        } catch (NumberFormatException e) {
            return "Erreur : les opérandes doivent être des nombres.";
        }
    }
}
